/**
 * Created by wj on 2018/8/7.
 * 该函数包含多个属性的运动框架，并添加了回调函数
 * obj 运动函数作用的对象
 * json 设置的多个属性的目标值
 * fn 回调函数，待animate这个函数的动画执行完毕后再去执行该函数，函数体中定时器停了即动画执行完毕
 */
function animate(obj,json,fn){
    clearInterval(obj.timer);              //先清除定时器
    obj.timer = setInterval(function(){
        var flag = true;                  //用来判断定时器是否已经停止
        for(var attr in json){           //遍历json，设置属性值
            var current = 0;

            if(attr == "opacity"){  //opacity透明度属性没有单位px，且值小于1，故先乘上100化为整数
                current = parseInt(getStyle(obj,attr)) * 100;
            }
            else{
                current = parseInt(getStyle(obj,attr));  //得到当前属性值
            }

            var step = (json[attr] - current) / 10;   //设置步长
            step = step>0 ? Math.ceil(step) : Math.floor(step);

            if(attr == "opacity"){
                if("opacity" in obj.style){         //判断浏览器是否兼容opacity
                    obj.style.opacity = (current + step) / 100;   //给属性赋我们设定的值
                }
                else{
                    obj.style.filter = "aipha(opacity="+(current + step)*10+")";
                }
            }
            else if(attr == "zIndex"){      //zIndex属性设置元素的堆叠顺序，直接赋值即可，不需要缓动动画
                obj.style.zIndex = json[attr];
            }
            else{
                obj.style[attr] = current + step +"px";   //给有单位px的属性设置值
            }
            if(json[attr] != current){  //其中一个不满足条件就不能停止计时器
                flag = false;
            }
        }
        if(flag){    //用于判断定时器是否停掉
            clearInterval(obj.timer);
            if(fn){fn();}  //若定时器停掉了，说明动画结束，此时如果有回调就执行回调
        }
    },30)
}
function getStyle(obj,attr){   //该函数返回对象obj的属性attr的当前值
    if(obj.currentStyle){
        return obj.currentStyle[attr];   //ie opera浏览器
    }
    else{
        return window.getComputedStyle(obj,null)[attr];  //w3c浏览器
    }
}